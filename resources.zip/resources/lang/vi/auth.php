<?php

return [
    'failed' => 'Tài khoản hoặc mật khẩu không chính xác.',
    'email'=> 'phải là một địa chỉ email hợp lệ và có đuôi .vn.',
    'name'=> 'phải có ít nhất 2 ký tự trở lên.',
    'password' => 'Mật khẩu không đúng.',
    'phone' => 'phải đúng 10 số.',
    'throttle' => 'Đăng nhập quá nhiều lần. Vui lòng thử lại sau :seconds giây.',
];
