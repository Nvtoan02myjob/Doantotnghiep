
<img src="{{ asset('assets/img/logo.png') }}" alt="Logo" width="100" style="border-radius: 50px; transition: 0.3s ease-in-out;"
     onmouseover="this.style.boxShadow='0px 4px 10px rgba(0, 0, 0, 0.3)'; this.style.transform='scale(1.1)';"
     onmouseout="this.style.boxShadow='none'; this.style.transform='scale(1)';"
>



