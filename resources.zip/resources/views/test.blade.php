<div>
    {{ $name }}
    {{ $email }}
    {{ $password }}
    {{ $phone }}
</div>
