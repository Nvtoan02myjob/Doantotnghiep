<div>
    <!-- An unexamined life is not worth living. - Socrates -->
</div>
<?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/vnpay/success.blade.php ENDPATH**/ ?>