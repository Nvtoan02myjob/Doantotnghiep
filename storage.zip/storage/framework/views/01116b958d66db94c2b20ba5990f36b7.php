<?php $__sessionArgs = ['title'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    Danh mục
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <h1>Loại tin</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a class="btn btn-info mb-3" href="<?php echo e(route('admin.type_news.create')); ?>">Thêm loại</a>

        <table class="table table-striped p-3 mt-3">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Loại</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $type_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($type->id); ?></td>
                        <td><?php echo e($type->name); ?></td>
                        <td>
                            <?php if($type->trashed()): ?>
                                <a href="<?php echo e(route('admin.type_news.restore', $type->id)); ?>" class="btn btn-primary btn-sm">Khôi phục</a>
                                <form action="<?php echo e(route('admin.type_news.forceDelete', $type->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Xóa vĩnh viễn loại tin này?')">Xóa vĩnh viễn</button>
                                </form>
                            <?php else: ?>
                                <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.type_news.edit', $type->id)); ?>">Sửa</a>
                                <form action="<?php echo e(route('admin.type_news.destroy', $type->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa loại tin này?')">Xóa</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($type_news->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/type_news/index.blade.php ENDPATH**/ ?>