<?php $__sessionArgs = ['title'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    Danh mục
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <h1>Danh mục</h1>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <a class="btn btn-info mb-3" href="<?php echo e(route('admin.categories.create')); ?>">Thêm danh mục</a>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Danh mục</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <?php if($category->trashed()): ?>
                                <!-- Hiển thị nút khôi phục và xóa vĩnh viễn nếu danh mục đã bị xóa mềm -->
                                <form action="<?php echo e(route('admin.categories.restore', $category)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success">Khôi phục</button>
                                </form>

                                <form action="<?php echo e(route('admin.categories.forceDelete', $category)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa vĩnh viễn danh mục này?')">Xóa vĩnh viễn</button>
                                </form>
                            <?php else: ?>
                                <!-- Hiển thị nút sửa và xóa bình thường nếu danh mục chưa bị xóa mềm -->
                                <a class="btn btn-warning" href="<?php echo e(route('admin.categories.edit', $category)); ?>">Sửa</a>
                                <a class="btn btn-success" href="<?php echo e(route('admin.categories.show', $category)); ?>">Xem</a>
                                <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa danh mục này?')">Xóa</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Phân trang -->
        <?php echo e($categories->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>