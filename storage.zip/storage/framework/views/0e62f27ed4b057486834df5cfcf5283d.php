<?php $__env->startSection('title', 'Thêm thanh toán'); ?>

<?php $__env->startSection('content'); ?>
<div class="m-2">
    <h1>Thêm thanh toán cho Đơn hàng <?php echo e($order->id); ?></h1>

    <!-- Hiển thị tổng tiền của đơn hàng -->
    <div class="mb-3">
        <strong>Tổng tiền đơn hàng: </strong><?php echo e(number_format($order->price_total)); ?>₫
    </div>

    <!-- Hiển thị thông tin người đặt (User ID) -->
    <div class="mb-3">
        <strong>Người đặt: </strong><?php echo e($order->user->name ?? 'N/A'); ?> (ID: <?php echo e($order->user->id ?? 'N/A'); ?>)
    </div>

    <!-- Form để thêm thanh toán -->
    <form action="<?php echo e(route('admin.payments.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="money">Số tiền nhận được</label>
            <input type="number" name="money" id="money" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="payment_method">Phương thức thanh toán</label>
            <select name="payment_method" id="payment_method" class="form-control" required>
                <option value="Cash">Tiền mặt</option>
                
            </select>
        </div>
        <div class="form-group">
            <label for="note">Ghi chú</label>
            <textarea name="note" id="note" class="form-control"></textarea>
        </div>

        <!-- Thêm các trường ẩn để gửi order_id và table_id -->
        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
        <input type="hidden" name="table_id" value="<?php echo e($order->table_id); ?>">
        <input type="hidden" name="user_id" value="<?php echo e($order->user->id ?? ''); ?>">

        <button type="submit" class="btn btn-primary">Thêm thanh toán</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/payments/create.blade.php ENDPATH**/ ?>