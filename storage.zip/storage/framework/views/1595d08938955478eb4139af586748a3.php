<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1>Danh sách bàn</h1>
    <a class="btn btn-info" href="<?php echo e(route('admin.tables.create')); ?>">Thêm bàn</a>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>QR Code</th>
                <th>Số người</th>
                <th>Trạng thái</th>
                <th>QR Image</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($table->id); ?></td>
                    <td><?php echo e($table->user_id); ?></td>
                    <td><?php echo e($table->qr_code); ?></td>
                   



                    <td><?php echo e($table->quantity_person); ?></td>
                    <td>
                    <span class="badge <?php echo e($table->status ? 'bg-success' : 'bg-warning'); ?>">
                        <?php echo e($table->status ? 'Đã có khách' : 'Còn trống'); ?>

                    </span>

                    </td>
                    <td>
                        <?php if($table->qr_img): ?>
                            <img src="<?php echo e(asset('storage/' . $table->qr_img)); ?>" alt="QR Image" width="80">
                        <?php else: ?>
                            Không có ảnh
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($table->deleted_at): ?>
                            <a href="<?php echo e(route('admin.tables.restore', $table->id)); ?>" class="btn btn-warning btn-sm mb-1">Khôi phục</a>

                            <form action="<?php echo e(route('admin.tables.forceDelete', $table->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa vĩnh viễn?')" class="btn btn-danger btn-sm">Xóa vĩnh viễn</button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.tables.edit', $table->id)); ?>" class="btn btn-primary btn-sm mb-1">Sửa</a>

                            <form action="<?php echo e(route('admin.tables.destroy', $table ->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger btn-sm">Xóa</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/tables/index.blade.php ENDPATH**/ ?>