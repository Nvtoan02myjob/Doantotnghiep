<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
    <h2>Chỉnh sửa món ăn</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Vui lòng kiểm tra lại dữ liệu!</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.dishes.update', $dish->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Tên món ăn</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $dish->name)); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Giá</label>
            <input type="number" name="price" class="form-control" value="<?php echo e(old('price', $dish->price)); ?>">
        </div>

        <div class="mb-3">
            <label class="form-label">Mô tả</label>
            <textarea name="description" class="form-control"><?php echo e(old('description', $dish->description)); ?></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Chọn danh mục</label>
            <select name="cate_id" required class="form-control">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>


        <div class="mb-3">
            <label class="form-label">Hình ảnh hiện tại</label><br>
            <?php if($dish->img): ?>
                <img  src="<?php echo e(asset('storage/'. $dish->img)); ?>" width="100" height="80" style="object-fit:cover;">
            <?php else: ?>
                Không có ảnh
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Chọn hình ảnh mới (nếu muốn đổi)</label>
            <input type="file" name="img" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Cập nhật món ăn</button>
        <a href="<?php echo e(route('admin.dishes.index')); ?>" class="btn btn-secondary">Quay lại</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/dishes/edit.blade.php ENDPATH**/ ?>