<div>
    bàn đã được chọn trước đó
</div>
<?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/Notification.blade.php ENDPATH**/ ?>