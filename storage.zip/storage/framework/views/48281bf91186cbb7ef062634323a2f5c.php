<?php $__env->startSection('title', 'Danh sách đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="m-2">
    <h1>Danh sách đơn hàng</h1>

    <table class="table table-striped p-3 mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Người đặt</th>
                <th>Bàn</th>
                <th>Mã PIN</th>
                <th>Tổng tiền</th>
                <th>Ngày đặt</th>
                <th>Trạng thái</th>
                <th>Thanh toán</th>
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->user->name ?? 'N/A'); ?></td>
                    <td><?php echo e($order->table_id ?? 'Chưa chọn'); ?></td>
                    <td><?php echo e($order->pin_code); ?></td>
                    <td><?php echo e(number_format($order->price_total)); ?>₫</td>
                    <td><?php echo e($order->created_at->format('d/m/Y H:i')); ?></td>
                    <td>
                        <span class="badge <?php echo e($order->status == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($order->status == 0 ? 'Đã thanh toán' : 'Chưa thanh toán'); ?>

                        </span>
                    </td>
                    <td>
                        <?php if($order->status == 1): ?>
                            <a href="<?php echo e(route('admin.payments.create', ['order_id' => $order->id])); ?>" class="btn btn-primary btn-sm">Thanh toán</a>
                        <?php else: ?>
                            <span class="text-success">Đã thanh toán</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.orders.show', $order->id)); ?>">Xem</a>

                        <form action="<?php echo e(route('admin.orders.destroy', $order->id)); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div style="font-size: 12px; padding: 5px;">
        <?php echo e($orders->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>