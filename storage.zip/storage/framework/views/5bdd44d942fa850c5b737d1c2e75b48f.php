<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xác nhận đăng ký</title>
</head>
<body>
    <h2>Xin chào,</h2>
    <p>Cảm ơn bạn đã đăng ký! Mã xác nhận của bạn là:</p>
    <h3 style="color: blue;"><?php echo e($code_auth); ?></h3>
    <p>Vui lòng nhập mã này để hoàn tất đăng ký.</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/emails/verify.blade.php ENDPATH**/ ?>