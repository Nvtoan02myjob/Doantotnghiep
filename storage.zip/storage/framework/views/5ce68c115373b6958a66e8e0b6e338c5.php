<?php $__sessionArgs = ['title'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    Danh sách bài viết
<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
<?php $__env->startSection('content'); ?>
<div class="container my-5">
<div class="row justify-content-center">
        <h1>Danh sách bài viết</h1>
        <a class="btn btn-info" href="<?php echo e(route('admin.news.create')); ?>">Thêm bài viết</a>

        
        

        <table class="table table-striped p-3 mt-3">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Tóm tắt</th>
                    <th>Ảnh đại diện</th>
                    <th>Thể loại</th>
                    <th>Ngày đăng</th>
                    <th>Tác giả</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($new->id); ?></td>

                        <td><?php echo e($new->title); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit(strip_tags($new->summary), 100)); ?></td>

                        <td>
                            <img src="<?php echo e(asset($new->image)); ?>" alt="Ảnh đại diện"
                                 style="width: 100px; height: 100px; object-fit: cover;">
                        </td>
                        <td><?php echo e($new->type_news->name); ?></td>
                        <td><?php echo e($new->created_at); ?></td>
                        <td><?php echo e($new->user->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.news.changeStatus', $new->id)); ?>"
                               class="btn btn-sm <?php echo e($new->status ? 'btn-success' : 'btn-secondary'); ?>">
                                <?php echo e($new->status ? 'Hiện' : 'Ẩn'); ?>

                            </a>
                        </td>
                        <td>
                            <?php if($new->trashed()): ?> <!-- Check if the article is soft-deleted -->
                                <a href="<?php echo e(route('admin.news.restore', $new->id)); ?>" class="btn btn-primary">Khôi phục</a>
                                <form action="<?php echo e(route('admin.news.forceDelete', $new->id)); ?>" method="POST" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa vĩnh viễn bài viết này?')">Xóa vĩnh viễn</button>
                                </form>
                            <?php else: ?>
                                <a class="btn btn-warning" href="<?php echo e(route('admin.news.edit', $new->id)); ?>">Sửa</a>
                                <a class="btn btn-success" href="<?php echo e(route('admin.news.show', $new->id)); ?>">Xem</a>
                                <form action="<?php echo e(route('admin.news.destroy', $new->id)); ?>" method="post" style="display: inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa bài viết này?')">Xóa</button>
                                </form>
                            <?php endif; ?>
                        </td>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <span style="font-size: 10px; padding: 3px;">
            <?php echo e($news->links('pagination::bootstrap-4')); ?>

        </span>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/news/index.blade.php ENDPATH**/ ?>