<?php $__sessionArgs = ['title'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    Chi tiết đơn hàng <?php echo e($order->id); ?>

<?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-2">
        <h1>Chi tiết đơn hàng <?php echo e($order->id); ?></h1>

        <p><strong>Người đặt:</strong> <?php echo e($order->user->name ?? 'N/A'); ?></p>
        <p><strong>Bàn:</strong> <?php echo e($order->table_id ?? 'Chưa chọn'); ?></p>
        <p><strong>Mã PIN:</strong> <?php echo e($order->pin_code); ?></p>
        <p><strong>Tổng tiền:</strong> <?php echo e(number_format($order->price_total)); ?>₫</p>
        <p><strong>Ngày đặt:</strong> <?php echo e($order->created_at->format('d/m/Y H:i')); ?></p>
        <p><strong>Trạng thái:</strong> 
            <span class="badge <?php echo e($order->status == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                <?php echo e($order->status == 1 ? 'Đã thanh toán' : 'Chưa thanh toán'); ?>

            </span>
        </p>

        <h3 class="mt-4">Danh sách món ăn</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Tên món</th>
                    <th>Số lượng</th>
                    <th>Đơn giá</th>
                    <th>Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($detail->dish->name ?? 'N/A'); ?></td>
                        <td><?php echo e($detail->quantity); ?></td>
                        <td><?php echo e(number_format($detail->unit_price)); ?>₫</td>
                        <td><?php echo e(number_format($detail->unit_price * $detail->quantity)); ?>₫</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-secondary">Quay lại</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>