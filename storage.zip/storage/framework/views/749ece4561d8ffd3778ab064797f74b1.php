<?php $__env->startSection('title', 'Danh sách thanh toán'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
            <h1>Danh sách thanh toán</h1>

    <div class="mb-3">
        <?php if($payments->isNotEmpty()): ?>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($payment->status == 0): ?>
                    <a href="<?php echo e(route('admin.payments.create', ['order_id' => $payment->order_id])); ?>" class="btn btn-primary">Thanh toán</a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <table class="table table-striped p-3 mt-3">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Đơn hàng</th>
                <th>Số tiền</th>
                <th>Phương thức</th>
                <th>Mã VNPAY</th>
                <th>Mã ngân hàng</th>
                <th>Ghi chú</th>
                <th>Trạng thái</th>
                <th>Thời gian thanh toán</th> 
                <th>Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($payment->id); ?></td>
                    <td><?php echo e($payment->order_id); ?></td>
                    <td><?php echo e(number_format($payment->money)); ?>₫</td>
                    <td><?php echo e($payment->payment_method); ?></td>
                    <td><?php echo e($payment->code_vnpay ?? '---'); ?></td>
                    <td><?php echo e($payment->code_bank ?? '---'); ?></td>
                    <td><?php echo e($payment->node ?? ''); ?></td>
                    <td>
                        <span class="badge <?php echo e($payment->status == 1 ? 'bg-success' : 'bg-secondary'); ?>">
                            <?php echo e($payment->status == 1 ? 'Đã thanh toán' : 'Chưa thanh toán'); ?>

                        </span>
                    </td>
                    <td>
                        <?php echo e($payment->updated_at->format('d/m/Y H:i')); ?>

                    </td>
                    <td>
                        <form action="<?php echo e(route('admin.payments.destroy', $payment->id)); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn xóa thanh toán này?')">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div style="font-size: 12px; padding: 5px;">
        <?php echo e($payments->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>