<script src="/sb-admin/vendor/jquery/jquery.min.js"></script>
<script src="/sb-admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="/sb-admin/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="/sb-admin/js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<!-- <script src="/sb-admin/vendor/chart.js/Chart.min.js"></script> -->

<!-- Page level custom scripts -->
<!-- <script src="/sb-admin/js/demo/chart-area-demo.js"></script> -->
<!-- <script src="/sb-admin/js/demo/chart-pie-demo.js"></script> -->

<script src="https://cdn.ckeditor.com/ckeditor5/36.0.1/classic/ckeditor.js"></script>






<?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/partials/js.blade.php ENDPATH**/ ?>