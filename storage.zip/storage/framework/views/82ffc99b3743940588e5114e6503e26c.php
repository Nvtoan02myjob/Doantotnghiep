 
 
 <?php $__env->startSection('content'); ?>
 <div class="container mt-5">
     <h2 class="mb-4 text-center">Danh sách phân quyền</h2>
     <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success mb-3">➕ Thêm phân quyền</a>
 
     <table class="table table-bordered table-hover">
         <thead class="table-Success">
             <tr>
                 <th>ID</th>
                 <th>Tên quyền</th>
                 <th>Thao tác</th>
             </tr>
         </thead>
         <tbody>
             <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($role->id); ?></td>
                     <td><?php echo e($role->role_name); ?></td>
                     <td>
                         <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-primary btn-sm"> Sửa</a>
                         <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" style="display:inline-block;">
                             <?php echo csrf_field(); ?>
                             <?php echo method_field('DELETE'); ?>
                             <button onclick="return confirm('Bạn có chắc muốn xoá không?')" class="btn btn-danger btn-sm">Xoá</button>
                         </form>
                     </td>
                 </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
     </table>
 </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>