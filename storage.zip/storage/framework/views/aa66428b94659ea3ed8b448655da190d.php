<?php $__env->startSection('title'); ?>
    Trang bàn order
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($tables->isNotEmpty()): ?>
            <div class="row">
                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-3">
                        <?php if($order_pendings->isNotEmpty()): ?>
                            <?php
                                $orderForTable = $order_pendings->firstWhere('table_id', $table->id);
                            ?>
                            <?php if($orderForTable): ?>
                                <div class="table-card admin_table_status p-3 text-center d-flex flex-column align-items-center" data-bs-toggle="modal" data-bs-target="#exampleModalDetailDish">
                                    <h6 class="mb-2" style="color: var(--color-text-white)">B<?php echo e($table->id); ?></h6>
                                    <div class="table_info">
                                        <p class="mb-1">
                                            <i class="bi bi-clock-fill"></i>
                                            <span class="time-elapsed" data-start="<?php echo e(\Carbon\Carbon::parse($orderForTable->created_at)->toIso8601String()); ?>">
                                                <?php echo e(\Carbon\Carbon::parse($orderForTable->created_at)->diff(now())->format('%h giờ %i phút %s giây')); ?>

                                            </span>
                                        </p>
                                        <p class="mb-0">
                                            <?php echo e(number_format($orderForTable->price_total)); ?>đ
                                        </p>
                                        
                                        
                                    </div>
                                </div>
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModalDetailDish" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Menu</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <table class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>stt</th>
                                                        <th>Tên món</th>
                                                        <th>Số lượng</th>
                                                        <th>Đơn giá</th>
                                                        <th>Đã gửi</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $i = 0;
                                                        $details = $detail_for_orderPendings->whereIn('order_id', [$orderForTable->id]);
                                                    ?>
                                                    <?php if($details): ?>
                                                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                
                                                                $dish = $dish_for_details->firstWhere('id', $detail->dish_id);
                                                            ?>
                                      
                                                            <tr>
                                                                <td>#<?php echo e(++$i); ?></td>
                                                                <td><?php echo e($dish->name); ?></td>
                                                                <td><?php echo e($detail->quantity); ?></td>
                                                                <td><?php echo e(number_format( $detail->unit_price)); ?>đ</td>
                                                                <td><input type="checkbox" data-id="<?php echo e($i); ?>" name="" class="checkbox_employee"></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                                            <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                                        </div>
                                        </div>
                                    </div>
                                </div>

                                <?php else: ?>
                                    <div class="table-card table_info_null p-3 text-center d-flex flex-column align-items-center">
                                        <h6 class="mb-2" style="color: var(--color-text-black)">B<?php echo e($table->id); ?></h6>
                                        <div>Trống</div>
                                        
                                    </div>
                                        
                            <?php endif; ?>

                            <?php else: ?>
                                <div class="table-card table_info_null p-3 text-center d-flex flex-column align-items-center">
                                    <h6 class="mb-2" style="color: var(--color-text-black)">B<?php echo e($table->id); ?></h6>
                                    <div>Trống</div>
                                    
                                </div>
                                        
                        <?php endif; ?>
                    </div>
            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/table_dish.blade.php ENDPATH**/ ?>