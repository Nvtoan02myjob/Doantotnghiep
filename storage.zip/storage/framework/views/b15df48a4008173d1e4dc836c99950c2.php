<nav aria-label="breadcrumb">
    <ol class="breadcrumb mb-0">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Trang chủ</a></li>
        <li class="breadcrumb-item active" aria-current="page">Giới thiệu</li>
    </ol>
</nav>
<?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/breadcrumb.blade.php ENDPATH**/ ?>