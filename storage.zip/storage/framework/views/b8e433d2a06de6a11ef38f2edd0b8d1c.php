<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
    <h2>Danh sách món ăn</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.dishes.create')); ?>" class="btn btn-success mb-3">Thêm món ăn mới</a>

    <table class="table table-bordered table-hover">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Ảnh</th>
                <th>Tên món</th>
                <th>Giá</th>
                <th>Mô tả</th>
                <th>Danh mục</th> 
                <th>Trạng thái</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr <?php if($dish->deleted_at): ?> style="background-color: #f8d7da;" <?php endif; ?>>
                    <td><?php echo e($dish->id); ?></td>
                    <td>
                        <?php if($dish->img): ?>
                            <img src="<?php echo e(asset('storage/' . $dish->img)); ?>" width="80" height="60" style="object-fit:cover;">
                        <?php else: ?>
                            Không có ảnh
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($dish->name); ?></td>
                    <td><?php echo e(number_format($dish->price)); ?> VNĐ</td>
                    <td><?php echo e($dish->description); ?></td>
                    
                        
                    <td>
                        <?php echo e($dish->category->name ?? 'Chưa phân loại'); ?>

                    </td>
                    
                    <td>
                        <?php if($dish->status): ?>
                            <span class="badge bg-success">Hiển thị</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Đang ẩn</span>
                        <?php endif; ?>
                    </td>
                   

                    <td>
                        <?php if($dish->deleted_at): ?>
                            <a href="<?php echo e(route('admin.dishes.restore', $dish->id)); ?>" class="btn btn-warning btn-sm mb-1">Khôi phục</a>

                            <form action="<?php echo e(route('admin.dishes.forceDelete', $dish->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa vĩnh viễn?')" class="btn btn-danger btn-sm">Xóa vĩnh viễn</button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.dishes.edit', $dish->id)); ?>" class="btn btn-primary btn-sm mb-1">Sửa</a>

                            <form action="<?php echo e(route('admin.dishes.destroy', $dish->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger btn-sm">Xóa</button>
                            </form>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.dishes.toggleStatus', $dish->id)); ?>" class="btn btn-warning btn-sm">
                            <?php if($dish->status): ?>
                                Ẩn
                            <?php else: ?>
                                Hiện
                            <?php endif; ?>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/dishes/index.blade.php ENDPATH**/ ?>