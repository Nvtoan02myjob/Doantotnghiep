<div>
    <?php echo e($order); ?>

</div>
<div>
    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <li><?php echo e($item); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</div>
<?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/payment.blade.php ENDPATH**/ ?>