<link rel="stylesheet" href="../assets/css/payment.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<div class="bill_modal">
    <div class="content_payment_bill" style=" padding-top: 20px;">
        <h5 class="text-center mb-4"><strong>Hóa đơn thanh toán</strong></h5>
        <table class="table table-bordered" style="margin: auto; width: 85% !important;">
            <thead>
                <tr>
                    <th class="text-center" style="width: 35%">Tên món</th>
                    <th class="text-center" style="width: 25%">Số lượng</th>
                    <th class="text-center" style="width: 20%">Đơn giá</th>
                    <th class="text-center" style="width: 20%">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data_list_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $dish = $dishs->where('id', $detail_item['dish_id'])->first();
                    ?>
                    <tr>
                        <td><?php echo e($dish['name']); ?></td>
                        <td><?php echo e($detail_item['quantity']); ?></td>
                        <td><?php echo e(number_format( $detail_item['unit_price'])); ?>đ</td>
                        <td><?php echo e(number_format($detail_item['unit_price'] *  $detail_item['quantity'])); ?>đ</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <P class="mt-4"><strong> Tổng tiền: <?php echo e(number_format($price)); ?>đ</strong></P>
        <img src="<?php echo e($QR); ?>" alt="ảnh QR" class="order_img_qr">
        <p><strong> Nội dung chuyển khoản: CKNH<?php echo e($content); ?></strong></p>


    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/payment_transfer.blade.php ENDPATH**/ ?>