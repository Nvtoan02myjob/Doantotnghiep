<?php $__env->startSection('title'); ?>
    Mã giảm giá 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-2">
        <h1>Mã giảm giá</h1>
        <a class="btn btn-info" href="<?php echo e(route('admin.voucher.create')); ?>">Thêm mã giảm giá</a>
        <table class="table table-striped p-3 mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Danh mục</th>
                    <th>Hình ảnh</th>
                    <th>Điều kiện</th>
                    <th>Thời gian kết thúc</th>
                    <th>Ngày tạo</th>
                    <th>Ngày cập nhật</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($voucher->name); ?></td>
                        <td><img src="<?php echo e(asset('storage/'.$voucher->image)); ?>" width="100"></td>
                        <td><?php echo e($voucher->condition); ?></td>
                        <td><?php echo e($voucher->time_end); ?></td>
                        <td><?php echo e($voucher->created_at); ?></td>
                        <td><?php echo e($voucher->updated_at); ?></td>
                        <td>
                        <a href="<?php echo e(route('admin.voucher.edit', $voucher->id)); ?>">Sửa</a>
                            <form action="<?php echo e(route('admin.voucher.destroy', $voucher->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Bạn có chắc chắn muốn xóa mã giảm giá này không?')">Xóa</button>
                            </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        <?php echo e($vouchers->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dream_stealers_restaurant\resources\views/admin/voucher/index.blade.php ENDPATH**/ ?>